# A simple tool to create modules and upload it in PyPi


Before using this module, you must create an account on GitHub and an account on Pypi.

You can do this using this links:
http://github.com

https://pypi.org/account/register/

And create a proyect in GitHub with MIT license and copy the URL

Doing this, you only need a python script which must have a principal class with the module methods.

For upload your module to pypi.org, you need to create a new python script in the directory of your class script and use the following code:

![Example Code](https://github.com/DanteAnnetta/pipmaker/blob/main/Example.png)

